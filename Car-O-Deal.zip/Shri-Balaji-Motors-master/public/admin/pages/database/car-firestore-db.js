const showAllCars = document.querySelector('.showAllCars');

const editCar = document.querySelector('#editCar');


/*** Upload Car Image  ***/

function uploadCarImage(event) {

    console.log(event.target.files[0]);

    let x = Math.floor(Math.random() * 1000000);
    let carid = document.getElementById("carID");
    let imageurl = document.getElementById("imageURL");

    const fileRef = firebase.storage().ref().child(`/cars/${x}`);
    const uploadTask = fileRef.put(event.target.files[0]);

    uploadTask.on('state_changed', 
        (snapshot) => {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            if(progress=='100') alert('Car Image Uploaded')
        }, 
        (error) => {
            console.log(error);
        }, 
        () => {
            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
            
            console.log('File available at', downloadURL);

            carid.value = x;
            imageurl.value = downloadURL;

            const cardocRef = firebase.firestore()
                .collection("cars")
                .doc(`${x}`);

                cardocRef.set({
                    imageURL: downloadURL
                })
                console.log("Car Added.")
            });
            
        }
    );
}

/** Upload Car Image on Edit **/

function uploadCarImageOnEdit(event) {

    console.log(event.target.files[0]);
    
    const editCarIdhash = window.location.hash;
    const editCarID = editCarIdhash.substring(1);

    let imageurl = document.getElementById("imageURL");

    const fileRef = firebase.storage().ref().child(`/cars/${editCarID}`);
    const uploadTask = fileRef.put(event.target.files[0]);

    uploadTask.on('state_changed', 
        (snapshot) => {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            if(progress=='100') alert('Car Image Uploaded')
        }, 
        (error) => {
            console.log(error);
        }, 
        () => {
            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
            
            console.log('File available at', downloadURL);

            imageurl.value = downloadURL;

            const cardocRef = firebase.firestore()
                .collection("cars")
                .doc(`${editCarID}`);

                cardocRef.update({
                    imageURL: downloadURL
                })
                console.log("Car Added.")
            });
            
        }
    );
}


/***  Add a New Car ***/

async function addCar(event) {

    event.preventDefault();

    const name = document.querySelector('#name');
    const brand = document.querySelector('#brand');
    const registrationYear = document.querySelector('#registrationYear');
    const city = document.querySelector('#city');
    const imageURL = document.querySelector('#imageURL');
    const carID = document.querySelector('#carID');
    const state = document.querySelector('#state');
    const inFeatured = document.querySelector('#inFeatured');

    var str = name.value;
    var new_name = str.replace(/ /g,"%20");

    const addCarRef = firebase.firestore()
        .collection("cars")
        .doc(`${carID.value}`);

    try {

        await addCarRef.update({
            
            name: name.value,
            brand: brand.value,
            registrationYear: registrationYear.value,
            city: city.value,
            imageURL: imageURL.value,
            carID: carID.value,
            state: state.value,
            inFeatured: inFeatured.value,
            whatsAppLink: "https://api.whatsapp.com/send?phone=919811172984&text=Hi%20Team%20Shri%20Balaji%20Motors,%0a%0aI%20would%20like%20to%20discuss%20about%20".concat(registrationYear.value,"%20",brand.value, "%20", new_name, "%20which%20is%20located%20in%20", city.value, ".", "%0a%0aKindly%20share%20more%20details.%0a%0aThanks"),

            isActive: "true",
            createdAt: firebase.firestore.Timestamp.now(),
            updatedAt: firebase.firestore.Timestamp.now(),       
        })
        alert(`${name.value} was added Successfully.`)
        window.location.replace("my-cars.html")
    } catch(err) {
        console.log(err);
    }
}


/***  To Display all the Cars  ***/

function showCars(userID) {

    const carsRef = firebase.firestore().collection("cars").orderBy("updatedAt", "desc");

    carsRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            
            const carInfo = doc.data();

            const dateFull = carInfo.updatedAt.toDate().toDateString();
            const dateNoDay = dateFull.substring(4); 
            const date = dateNoDay.slice(0,-5);

            /** Show All Cars **/

            if($('body').is('.showCars')){

                var delay = "";
                let hours = 0;
                let minutes = 0;
                var oldDate = carInfo.updatedAt.toDate();
                var newDate = new Date();
                var diffMs = (newDate - oldDate);
                var diffDays = Math.floor(diffMs / 86400000); // days
                var diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
                var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); // minutes

                if(!(diffDays == 0)) {
                    const dateFull = carInfo.updatedAt.toDate().toDateString();
                    const dateNoDay = dateFull.substring(4); 
                    delay = dateNoDay.slice(0,-5);
                    console.log(delay)
                } else {
                    if(!(diffHrs == 0)) {
                        hours = diffHrs
                        if(diffHrs == 1){ delay = (`${diffHrs} hour ago`) }
                        else { delay = (`${diffHrs} hours ago`) }
                        console.log(delay)
                    } else {
                        if(!(diffMins == 0)) {
                            minutes = diffMins
                            if(diffMins == 1){ delay = (`${diffMins} min ago`) }
                            else { delay = (`${diffMins} mins ago`) }
                            console.log(delay)
                        } else {
                            delay = "Just Now"
                            console.log(delay)
                        }
                    }
                }
            
                showAllCars.innerHTML += `

                    <div class="container-xxl py-5">
                        <div class="container">
                                <div class="bg-white rounded p-4">
                                    <div class="row g-9 align-items-center">
                                        <div class="col-lg-9 wow fadeIn" data-wow-delay="0.1s">
                                            <a><h5>${carInfo.brand} ${carInfo.name}</h5></a>
                                            <p><b>City of Car Located:</b> ${carInfo.city}</p>
                                            <p><b>Registration Year:</b> ${carInfo.registrationYear}</p>
                                            <p><b>State of Registration:</b> ${carInfo.state}</p>
                                            <p><b>Fuel Type:</b> ${carInfo.fuel}</p>
                                            <p><b>Last Updated:</b> ${date}</p><br>
                                            <p><b>Displaying in Featured:</b> ${(carInfo.isFeatured == "true" ? "Yes" : "No" )}</p><br>
                                            <p><b>Status:</b> ${(carInfo.isActive == "true" ? "Active" : "Disabled" )}</p><br>
                                            <td class="td-actions text-right">
                                                <div class="form-button-action">
                                                    <a href="edit-car.html#${doc.id}"><button type="button" data-toggle="tooltip" title="Edit Car" class="btn btn-link btn-simple-primary">
                                                        <i class="la la-edit la-2x"></i> Edit
                                                    </button></a>
                                                    <div id="closeReq"><a href="#${doc.id}"><button type="button" title="Disable" class="btn btn-link btn-simple-danger" data-toggle="modal" data-target="#closeRequirement">
                                                        <i class="la la-trash la-2x"></i> Disable
                                                    </button></a></div>
                                                    <div id="repostReq"><a href="#${doc.id}"><button type="button" title="Enable" class="btn btn-link btn-simple-success" data-toggle="modal" data-target="#repostRequirement">
                                                        <i class="la la-refresh la-2x"></i> Enable
                                                    </button></a></div>
                                                    <div id="repostReq"><a href="#${doc.id}"><button type="button" title="Enable" class="btn btn-link btn-simple-success" data-toggle="modal" data-target="#repostRequirement">
                                                        <i class="la la-refresh la-2x"></i> delete
                                                    </button></a></div>
                                                </div>
                                            </td>
                                        </div>
                                        <div class="col-lg-3 wow fadeIn">
                                            <img class="img-fluid" src=${carInfo.imageURL}>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `

            }

            /** Edit Car Details **/

            if($('body').is('.editCar')){

                const editCarIdhash = window.location.hash;
                const editCarID = editCarIdhash.substring(1);

                const cardocRef = firebase.firestore()
                .collection("cars")
                .doc(editCarID);

                cardocRef.onSnapshot((doc) => {
                    if(doc.exists) {
                        const carInfo = doc.data();

                        if(carInfo){
                            editCar["name"].value = carInfo.name;
                            editCar["brand"].value = carInfo.brand;
                            editCar["registrationYear"].value = carInfo.registrationYear;
                            editCar["city"].value = carInfo.city;
                            editCar["state"].value = carInfo.state;
                            editCar["imageURL"].value = carInfo.imageURL;
                            editCar["inFeatured"].value = carInfo.inFeatured;
                        }

                    }
                })
            }


        });
    });
}


/*** To Edit the Car Added ***/

async function updateCarDetails(event) {

    event.preventDefault();

    const carIdhash = window.location.hash;
    const carId = carIdhash.substring(1);
    
    const updateCarRef = firebase.firestore()
        .collection("cars")
        .doc(carId);
    try {
        await updateCarRef.update({

            name: editCar["name"].value,
            brand: editCar["brand"].value,
            registrationYear: editCar["registrationYear"].value,
            city: editCar["city"].value,
            state: editCar["state"].value,
            fuel: editCar["fuel"].value,
            imageURL: editCar["imageURL"].value,
            inFeatured: editCar["inFeatured"].value,
            updatedAt: firebase.firestore.Timestamp.now(),          
        })
        alert(`Details for ${editCar["brand"].value} ${editCar["name"].value} were Updated Successfully.`)
        window.location.replace("my-cars.html")
    } catch(err) {
        console.log(err);
    }     
}

                                        /*** Reset the Password in Settings ***/


async function resetTutorPass(event) {

    var user = firebase.auth().currentUser;
    var email = user.email;
    try {
        await firebase.auth().sendPasswordResetEmail(email);
        alert("Link Sent Successfully to your Registered Email. Kindly check.")
    }  catch(err) {
        console.log(err);
    }
}

















