// Check if Password and Confirm Password is Same
var check = function() {
        if (document.getElementById('signUpPassword').value ==
            document.getElementById('confirm_password').value) {
            document.getElementById('message').style.color = 'green';
            document.getElementById('message').innerHTML = 'Password are Matched';
        } else {
            document.getElementById('message').style.color = 'red';
            document.getElementById('message').innerHTML = 'Password not Matched';
        }
    }

// Check if Email is Valid or not
function validateEmail(email) { 
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
} 


function continueornot() {
    if(validateEmail(document.getElementById('signUpEmail').value)){
        document.getElementById('invalid_email').style.color = 'green';
        document.getElementById('invalid_email').innerHTML = 'Email is Valid';
    }else{ 
        document.getElementById('invalid_email').style.color = 'red';
        document.getElementById('invalid_email').innerHTML = 'Email is not Valid';
        return false;
    }
}

function continueornotreset() {
    if(validateEmail(document.getElementById('reset_email').value)){
        document.getElementById('invalid_email').style.color = 'green';
        document.getElementById('invalid_email').innerHTML = 'Email is Valid';
    }else{ 
        document.getElementById('invalid_email').style.color = 'red';
        document.getElementById('invalid_email').innerHTML = 'Email is not Valid';
        return false;
    }
}