                                            /***  Sign In using Credentials  ***/

async function signin(event) {
    event.preventDefault();
    const email = document.querySelector('#loginEmail');
    const password = document.querySelector('#loginPassword');
    try{
        const result = await firebase.auth().signInWithEmailAndPassword(email.value, password.value);
        document.getElementById("signin_message").innerHTML = `Sign In Successful. Redirecting....`;
        document.getElementById('signin_message').style.color = 'green';

        var user = firebase.auth().currentUser;

        if(user){
            window.location.replace("dashboard/my-cars.html");
        }

    }catch(err){
        console.log(err);
        document.getElementById("signin_message").innerHTML = `Oops! Wrong Email/Password. Kindly check and try again.`;
        document.getElementById('signin_message').style.color = 'red';
    }
    email.value="";
    password.value="";
}



                                            /***  Sign Out  ***/

async function signout() {
    try {
        const result = await firebase.auth().signOut();
        window.location.replace("../index.html");
    } catch(error) {
        alert(error.message);
    }
}

const unsubscribe = firebase.auth().onAuthStateChanged((user) => {
        
    if (user) {
  
        showCars(user.uid);
        console.log("Admin is Logged In"); 
        
    } else {
        console.log("Admin is Not Logged In")
    }
});