const firebaseConfig = {
    apiKey: "AIzaSyD17Xp912LC-pFE-t2u6M2qPbZHy1F52Rw",
    authDomain: "ishri-balaji-motors.firebaseapp.com",
    databaseURL: "https://ishri-balaji-motors-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "ishri-balaji-motors",
    storageBucket: "ishri-balaji-motors.appspot.com",
    messagingSenderId: "1034333866936",
    appId: "1:1034333866936:web:0242400e362c48d8ee5d4d",
    measurementId: "G-NVJF6JV29W"
  };

  //initialise
  firebaseConfig.initializeApp(firebaseConfig);

  //reference
 const contactformDB = firebase.database().ref('contactform')