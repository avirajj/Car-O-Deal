const showAllActiveCars = document.querySelector('.showAllActiveCars');
const showFeaturedCars = document.querySelector('.showFeaturedCars');

const unsubscribe = firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        showCarsLive()
        showCarsFeatured()
    } else {
        showCarsLive()
        showCarsFeatured()
    }
});


/*** To Show all the Cars that are Active and Available  ***/

function showCarsLive() {

    const carsRef = firebase.firestore().collection("cars");

    carsRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            const carInfo = doc.data();

            if(carInfo.isActive == "true"){

                const dateFull = carInfo.updatedAt.toDate().toDateString();
                const dateNoDay = dateFull.substring(4); 
                var date = dateNoDay.slice(0,-5);

                if($('body').is('.cars')){

                    showAllActiveCars.innerHTML += `
                        <div class="col-md-4">
                            <div class="car-wrap rounded">
                                <div class="img rounded d-flex align-items-end" style="background-image: url(${carInfo.imageURL});">
                                </div>
                                <div class="text">
                                    <h2 class="mb-0"><a href="car-single.html">${carInfo.brand} ${carInfo.name}</a></h2>
                                    <div class="d-flex mb-3">
                                        <span class="cat">${carInfo.city} Located</span>
                                        <p class="price ml-auto">${carInfo.registrationYear}<span> model</span></p>
                                    </div>
                                    <div class="d-flex mb-3">
                                        <span class="cat"><b>Registered</b> ${carInfo.state} </span>
                                    </div>
                                    <div class="d-flex mb-3">
                                        <p class="price ml-auto">${dateNoDay}</p>
                                    </div>
                                    <p class="d-flex mb-0 d-block"><a href="tel:+919811172984" class="btn btn-primary py-2 mr-1">Call now</a> <a href="${carInfo.whatsAppLink}" class="btn btn-secondary py-2 ml-1">WhatsApp Now</a></p>
                                </div>
                            </div>
                        </div>
                    `

                }
                

            }
        })
    })
}


/*** To Show all the Cars that are Featured  ***/

function showCarsFeatured() {

    const carsRef = firebase.firestore().collection("cars");

    carsRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            const carInfo = doc.data();

            if(carInfo.inFeatured == "true"){

                const dateFull = carInfo.updatedAt.toDate().toDateString();
                const dateNoDay = dateFull.substring(4); 
                var date = dateNoDay.slice(0,-5);

                if($('body').is('.index')){

                    showFeaturedCars.innerHTML += `
                        <div class="item">
                            <div class="car-wrap rounded ftco-animate">
                                <div class="img rounded d-flex align-items-end" style="background-image: url(${carInfo.imageURL});">
                                </div>
                                <div class="text">
                                    <h2 class="mb-0"><a href="#">${carInfo.brand} ${carInfo.name}</a></h2>
                                    <div class="d-flex mb-3">
                                        <span class="cat">${carInfo.city} Located</span>
                                        <p class="price ml-auto">${carInfo.registrationYear}<span> model</span></p>
                                    </div>
                                    <div class="d-flex mb-3">
                                        <span class="cat"><b>Registered</b> ${carInfo.state} </span>
                                    </div>
                                    <div class="d-flex mb-3">
                                        <p class="price ml-auto">${dateNoDay}</p>
                                    </div>
                                    <p class="d-flex mb-0 d-block"><a href="tel:+919811172984" class="btn btn-primary py-2 mr-1">Call now</a> <a href="${carInfo.whatsAppLink}" class="btn btn-secondary py-2 ml-1">WhatsApp Now</a></p>
                                </div>
                            </div>
                        </div>
                    `

                }
                

            }
        })
    })
}
